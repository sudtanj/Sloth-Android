package com.example.database.dao;



import com.example.database.DatabaseHelper;

import java.sql.SQLException;


public class DAO
{
	public static void printDatabaseInfo()
	{
		/*//DatabaseHelper databaseHelper = DatabaseHelper.getInstance();
		try
		{
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}*/
	}
}
