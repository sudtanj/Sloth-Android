# HCI-Sloth

## Project Member
| No | Profile Picture | Member Name | Github Userid | Student Id Number |
| ------ | ------ | ------ | ------ | ------ |
| 1. | <img src="https://avatars.githubusercontent.com/bryanchr" width=100 height=100 /> |Bryan Christofel Yehezkiel | <a title="@bryanchr" href="https://github.com/bryanchr">@bryanchr</a> | 00000016528 | 
| 2. | <img src="https://avatars.githubusercontent.com/feroniameimei" width=100 height=100/> | Feronia Meilinda | <a title="@feroniameimei" href="https://github.com/feroniameimei">@feroniameimei</a> |   00000012566 |
| 3. | <img src="https://avatars.githubusercontent.com/liuzen" width=100 height=100/> | Hendrian Lunardi | <a title="@liuzen" href="https://github.com/liuzen">@liuzen</a> |           00000012778 |
| 4. | <img src="https://avatars.githubusercontent.com/izzyengelbert" width=100 height=100/> | Izzy S |<a title="@izzyengelbert" href="https://github.com/izzyengelbert">@izzyengelbert</a>  |  00000018656 |
| 5. | <img src="https://avatars.githubusercontent.com/chocochino" width=100 height=100/> | Livia Andriana Lohanda |<a title="@chocochino" href="https://github.com/chocochino">@chocochino</a>  | 00000013401 |
| 6. | <img src="https://avatars.githubusercontent.com/SamuelTeguh" width=100 height=100/> | Samuel Teguh |<a title="@SamuelTeguh" href="https://github.com/SamuelTeguh">@SamuelTeguh</a>  |  00000012383 |
| 7. | <img src="https://avatars.githubusercontent.com/sudtanj" width=100 height=100/> | Sudono Tanjung | <a title="@sudtanj" href="https://github.com/sudtanj">@sudtanj</a> |              				 00000012273 |
| 8. | <img src="https://avatars.githubusercontent.com/VrGun" width=100 height=100/> | Veri Gunawan | <a title="@VrGun" href="https://github.com/VrGun">@VrGun</a> |              				 00000012343 |
